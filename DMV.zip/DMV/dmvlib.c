//
// Created by Sangye Sherpa on 11/21/18.
//
#include "dmvlib.h"

char* readCustomerName(){
    char* tempCustomerName = malloc(75* sizeof (char));
    printf("Enter customer name\n");
    scanf("%s", tempCustomerName);
    return  tempCustomerName;

}

Customers* allocateCustomer(){
    Customers* newTempCustomer = malloc(sizeof(Customers));
    newTempCustomer->name = "";
    newTempCustomer->next = NULL;
}

Customers* addNewCustomer(Customers* previous){

    Customers* newCustomer = malloc(sizeof(Customers));
    newCustomer->name = malloc(75 * sizeof (char));

    printf("Enter customer name\n");
    scanf("%s", newCustomer->name);

    newCustomer->next = previous;

    return newCustomer;
}

void printAll(Customers* previous) {
    Customers* tempNode = previous;
    printf("The line is: \n");

    while(tempNode != NULL){
        printf ("%s", tempNode->name);
        tempNode = tempNode->next;
        printf("<-");

    }
    printf("\n");
}