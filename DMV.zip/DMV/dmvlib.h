//
// Created by Sangye Sherpa on 11/21/18.
//

#ifndef PROGRAM5_1_DMVLIB_H
#define PROGRAM5_1_DMVLIB_H

#include <stdlib.h>
#include <stdio.h>

typedef struct _customers {
    char* name;
    struct _customers* next;
} Customers;

typedef struct _lineOfCustomers{
    struct _customers *head;
} LineOfCustomers;

void printAll(Customers*);

Customers* addNewCustomer(Customers*);

char* readCustomerName();

Customers* allocateCustomer();

#endif //PROGRAM5_1_DMVLIB_H
