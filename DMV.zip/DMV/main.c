//
// Created by Sangye Sherpa on 11/21/18.
//
#include "dmvlib.h"

int main() {

    int names = 0;

    Customers *lastCustomer = NULL;

    while(names != 3) {
        printf ("\n1) Add customer"
                "\n2) Print Customer list"
                "\n3) Exit:");
        scanf (" %d", &names);

        if (names == 1) {
            lastCustomer = addNewCustomer(lastCustomer);
        }
        else if (names == 2) {
            printAll(lastCustomer);
        }
        else if (names == 3) {
            printf("Ending program");
        }
        else {
            printf ("Invalid option\n");
        }
    }
}
